package intellect25.model;

import java.util.LinkedList;
import java.util.List;

/**
 * This class for a necklace
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class NecklaceImpl implements Necklace {

    /**
     * List of necklace
     */
    private LinkedList<Stone> necklace = new LinkedList<>();

    /**
     * Default constructor
     */
    public NecklaceImpl(){}

    /**
     * Constructor with entered list of a necklace
     *
     * @param necklace entered a necklace
     */
    public NecklaceImpl(List<Stone> necklace) {
            setNecklace(necklace);
    }

    /**
     * Constructor for creating automatically a necklace
     *
     * @param size size of necklace
     */
    public NecklaceImpl (int size){
        generateStone(size);
    }

    /**
     * Generate stones for a necklace
     *
     * @param size size of a necklace
     */
    private void generateStone(int size){
        int i= 0;
        while (i < size) {
            Stone stone = RandomStone.create();
            setStone(stone);
            i++;
        }
    }

    /**
     * Check price
     *
     * @return true or false
     */
    @Override
    public boolean checkPrice(){
        for (Stone stone : necklace){
            if (stone.getPrice() < 0)
                return false;
        }
        return true;
    }

    /**
     * Get size of  necklace
     *
     * @return size
     */
    @Override
    public int getSizeNecklace() {
        return necklace.size();
    }

    /**
     * Get a  necklace
     *
     * @return necklace
     */
    @Override
    public LinkedList<Stone> getNecklace() {
        return necklace;
    }

    /**
     * Set a necklace
     *
     * @param necklace necklace
     */
    @Override
    public void setNecklace(List<Stone> necklace) {
            this.necklace.addAll(necklace);
    }

    /**
     * Set a stone to the necklace
     *
     * @param stone entered stone
     */
    @Override
    public void setStone(Stone stone) {
        necklace.add(stone);
    }

    /**
     * Count sum of weight and price of all stones
     *
     * @return array of result
     */
    @Override
    public Result resultWeightPrice(){
        double totalWeight = 0;
        double totalPrice = 0;

        for (Stone stone : getNecklace()){
            totalWeight += stone.getWeight();
            totalPrice += stone.getPrice();
        }

        Result result = new Result(Calculation.round(totalWeight,2),Calculation.round(totalPrice, 2));
        return result;
    }
}
