package intellect25.model;

import java.util.List;

/**
 * This class for a creating a necklace
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Factory {

    /**
     * Constructor private
     */
    private Factory(){}

    /**
     * Create class Necklace without entered parameters
     *
     * @return class Necklace
     */
    public static Necklace createNecklace(){
        return new NecklaceImpl();
    }

    /**
     * Create class Necklace with entered list of stones
     *
     * @param necklace list of stones
     * @return class Necklace
     */
    public static Necklace createNecklace(List<Stone> necklace){
        return new NecklaceImpl(necklace);
    }

    /**
     * Create class Necklace with entered size of list of stones
     * for automated generated stones
     *
     * @param size size of necklace
     * @return class Necklace
     */
    public static Necklace createNecklace(int size){
        return new NecklaceImpl(size);
    }
}
