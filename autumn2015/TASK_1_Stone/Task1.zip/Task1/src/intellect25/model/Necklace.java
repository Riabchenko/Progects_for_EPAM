package intellect25.model;

import java.util.LinkedList;
import java.util.List;

/**
 * This interface for a necklace
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public interface Necklace {

    /**
     * Check price
     *
     * @return true or false
     */
    boolean checkPrice();

    /**
     * Get size of  necklace
     *
     * @return size
     */
    int getSizeNecklace();

    /**
     * Get a  necklace
     *
     * @return necklace
     */
    LinkedList<Stone> getNecklace();

    /**
     * Set a necklace
     *
     * @param necklace necklace
     */
    void setNecklace(List<Stone> necklace);

    /**
     * Set a stone to the necklace
     *
     * @param stone entered stone
     */
    void setStone(Stone stone);

    /**
     * Count sum of weight and price of all stones
     *
     * @return array of result
     */
    Result resultWeightPrice();
}
