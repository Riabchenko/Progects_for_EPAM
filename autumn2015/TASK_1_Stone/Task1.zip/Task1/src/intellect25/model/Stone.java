package intellect25.model;

import intellect25.model.characteristic.*;

/**
 * This class for a stone
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Stone {

    /** Price of stone */
    private double price;

    /** Weight of stone */
    private double weight;

    /** Type of stone */
    private TypeStone typeStone;

    /** Color of stone*/
    private Color color;

    /** Clarity of stone*/
    private Clarity clarity;

    /**Cut of stone*/
    private Cut cut;

    /** Form of stone*/
    private Form form;

    /**
     * Constructor with parameters
     *
     * @param semiPresiour semi presiour stone
     * @param color color of stone
     * @param clarity clarity of stone
     * @param cut cut of stone
     * @param form form of stone
     * @param dimetrOrLenght dimetr or lenght of stone
     * @param width width of stone
     * @param height height of stone
     */
    public Stone(TypeStone semiPresiour, Color color, Clarity clarity, Cut cut, Form form,
                 float dimetrOrLenght, float width,float height) {
        init(semiPresiour, color, clarity, cut, form, dimetrOrLenght, width, height);
    }

    /**
     * Initialisation parameters
     *
     * @param semiPresiour semi presiour stone
     * @param color color of stone
     * @param clarity clarity of stone
     * @param cut cut of stone
     * @param form form of stone
     * @param dimetrOrLenght dimetrOrLenght of stone
     * @param width width of stone
     * @param height height of stone
     */
    public void init(TypeStone semiPresiour, Color color, Clarity clarity, Cut cut, Form form,
                     float dimetrOrLenght, float width,float height){
        setTypeStone(semiPresiour); //set type of stone
        setColor(color);//set color
        setClarity(clarity);//set clarity
        setCut(cut);//set cut
        setForm(form);//set form
        setWeight(dimetrOrLenght, width, height);//set weight

        /* set price,it always must initialize at the end */
        if (this.color != null && this.clarity != null && this.cut != null && this.weight != 0.0)
            setPrice();
    }

    /**
     * Get weight of stone
     *
     * @return weight
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Set weight of stone
     *
     * @param dimetrOrLenght dimetr or lenght of stone
     * @param width width  of stone
     * @param height height  of stone
     */
    public void setWeight(float dimetrOrLenght, float width,float height) {
        weight = typeStone.getWeight(getForm(),dimetrOrLenght,width,height);
    }

    /**
     * Get price of stone
     *
     * @return price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Set price of stone. Use this method only after initialization
     * color, weight, clarity and cut
     */
    public void setPrice() {
       price = Calculation.getPrice(this);
    }

    /**
     * Get type of stone
     *
     * @return type of stone
     */
    public TypeStone getTypeStone() {
        return typeStone;
    }

    /**
     * Set type of stone
     *
     * @param typeStone type of stone
     */
    public void setTypeStone(TypeStone typeStone) {
        this.typeStone = typeStone;
    }

    /**
     * Get color
     *
     * @return color
     */
    public Color getColor() {
        return color;
    }

    /**
     * Set color
     *
     * @param color color
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Get clarity of stone
     *
     * @return clarity
     */
    public Clarity getClarity() {
        return clarity;
    }

    /**
     * Set clarity to stone
     *
     * @param clarity clarity to stone
     */
    public void setClarity(Clarity clarity) {
        this.clarity = clarity;
    }

    /**
     * Get cut from stone
     * @return cut
     */
    public Cut getCut() {
        return cut;
    }

    /**
     * Set cut to stone
     *
     * @param cut entered cut
     */
    public void setCut(Cut cut) {
        this.cut = cut;
    }

    /**
     * Get form
     *
     * @return form
     */
    public Form getForm() {
        return form;
    }

    /**
     * Set form
     *
     * @param form form
     */
    public void setForm(Form form) {
        this.form = form;
    }

    /**
     * Round number
     * @param number entered number
     * @return round number
     */
    public double round(double number){
       return Calculation.round(number, 2);
    }

}
