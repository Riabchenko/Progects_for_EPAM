package intellect25.model;

import intellect25.model.characteristic.*;

/**
 * This class is a calculation for price of stone
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Calculation implements FinalParameter {

    /**
     * Get price of a stone
     *
     * @param stone entered a stone
     * @return price of a stone
     */
    public static double getPrice(Stone stone) {

        /* Check minimal weight of a stone*/
        if (stone.getWeight() >= MIN_WEIGHT) {

            /*Check class is a Gemstone*/
            if (isGemstone(stone.getTypeStone())) {

			    /*Check class is a DIAMOND*/
                if ((Gemstone) stone.getTypeStone() == Gemstone.DIAMOND)
                    return calculateColorOfDiamond(stone);
                else return calculateTone(stone);
            } else  return calculateTone(stone);
        }else return NOT_RESULT;
    }

    /**
     * Round number
     *
     * @param value number
     * @param scale count of a number after a point
     * @return round number
     */
    public static double round(double value, int scale) {
        return Math.round(value * Math.pow(BASE_NUMBER, scale)) / Math.pow(BASE_NUMBER, scale);
    }

    /**
     * Check type of stone is it a gemstone or isn't
     *
     * @param typeStone stone
     * @return true if it's gemstone
     */
    public static boolean isGemstone(TypeStone typeStone){
        if (typeStone instanceof Gemstone){
             return  true;
        }
        return false;
    }

    /**
     * Calculate price of a stone which isn't a diamond
     *
     * @param stone stone which isn't a diamond
     * @return price
     */
    public static double calculateTone(Stone stone){

        /* Check type of color*/
        if (stone.getColor() instanceof Tone) {
            Tone tone = (Tone) stone.getColor();
            double col = (tone.ordinal() + ONE) * СOEFFICIENT_COLOR;
            double clar = (stone.getClarity().ordinal() + ONE) * СOEFFICIENT_CLARITY;
            double c = (stone.getCut().ordinal() + ONE) * СOEFFICIENT_CUT;
            double startPrice = stone.getTypeStone().getBasePrice() * Math.pow(stone.getWeight(), ONE - stone.getWeight());
            return round(startPrice + col + clar + c, AFTER_POINT);
        } else return ERROR;
    }

    /**
     * Calculate price of a diamond
     *
     * @param stone diamond
     * @return price of a diamond
     */
    public static double calculateColorOfDiamond(Stone stone){

        /* Check type of color*/
        if (stone.getColor() instanceof ColorOfDiamond) {
            ColorOfDiamond colorOfDiamond = (ColorOfDiamond) stone.getColor();
            double startPrice = stone.getTypeStone().getBasePrice() * Math.pow(stone.getWeight(), stone.getWeight() - СOEFFICIENT_START_PRICE);
            double col = colorOfDiamond.ordinal() * СOEFFICIENT_COLOR_DIAMANT * startPrice;
            double clar = stone.getClarity().ordinal() * СOEFFICIENT_CLARITY_DIAMANT * startPrice / СOEFFICIENT_CLARITY_HUNDRED;
            double c = stone.getCut().ordinal() * СOEFFICIENT_CUT * startPrice;
            return round(startPrice + col + clar + c, AFTER_POINT);
        } else return ERROR;
    }
}
