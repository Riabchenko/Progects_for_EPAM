package intellect25.model.characteristic;

/**
 * This interface for stone from Gemstone and SemiPrecious
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public interface TypeStone extends FinalParameter {

    /**
     *  Get base price from stone
     *
     * @return price
     */
    double getBasePrice();

    /**
     * Get weight from stone
     *
     * @param form form of stone
     * @param diametrOrLenght diametr or lenght of stone
     * @param widht widht of stone
     * @param height height of stone
     * @return weight of stone
     */
    double getWeight(Form form, float diametrOrLenght, float widht, float height);
}
