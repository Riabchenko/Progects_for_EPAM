package intellect25.model.characteristic;

import intellect25.model.Calculation;

/**
 * This class enumerates types of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public enum SemiPrecious implements TypeStone {
	AGAT(2.60f,0.1d),OPAL(2.00f,0.1);

	private float density;//density of stone
	private double basePrice;

	/**
	 * Constructor
	 *
	 * @param density density of stone
	 * @param basePrice base price
	 */
	SemiPrecious(float density, double basePrice){
		this.density = density;
		this.basePrice = basePrice;
	}

	/**
	 * Get density of stone
	 *
	 * @return density
	 */
	private float getDensity(){
		return density;
	}

	/**
	 * Get base price of stone
	 *
	 * @return base price
	 */
	public double getBasePrice(){
		return basePrice;
	}

	/**
	 * Get weight of stone
	 *
	 * @param form Form of stone
	 * @param diametrOrLenght diametr or lenght of stone
	 * @param widht widht of stone
	 * @param height height of stone
	 * @return weight of stone
	 */
	public double getWeight(Form form,float diametrOrLenght,float widht,float height){
		if(Form.ROUND == form) widht = diametrOrLenght;
		double weight = getWeightForSet(form, diametrOrLenght, widht, height);
		return weight;
	}

	/**
	 * Helper for getWeight
	 *
	 * @param form Form of stone
	 * @param diametrOrLenght  diametr or lenght of stone
	 * @param widht widht of stone
	 * @param height height of stone
	 * @return weight of stone
	 */
	private double getWeightForSet(Form form,float diametrOrLenght,float widht,float height){
		return Calculation.round((diametrOrLenght * widht * height * getDensity() * form.getProperty()), AFTER_POINT);
	}


}
