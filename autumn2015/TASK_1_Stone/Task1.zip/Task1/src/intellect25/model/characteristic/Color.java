package intellect25.model.characteristic;


/**
 * This interface  combines color of ColorDiamond and color of Tone
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public interface Color {
}
