package intellect25.model.characteristic;

/**
 * This interface for finale parameter that use at the TypeStone
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public interface FinalParameter {
     int ERROR = -1;
     double MIN_WEIGHT = 0.01;
     double СOEFFICIENT_START_PRICE = 0.01;
     double СOEFFICIENT_COLOR_DIAMANT = 0.42;
     double СOEFFICIENT_COLOR = 0.15096;
     double СOEFFICIENT_CLARITY_DIAMANT = 0.15;
     double СOEFFICIENT_CLARITY = 0.42087;
     double СOEFFICIENT_CLARITY_HUNDRED = 100;
     double СOEFFICIENT_CUT = 0.2;
     int AFTER_POINT = 2;
     int BASE_NUMBER = 10;
     int ONE = 1;
     int NOT_RESULT = 0;
}
