package intellect25.model.characteristic;

/**
 * This class enumerates Tone of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public enum Tone implements Color {
    DARK,MIDDLE_DARK,SLOW_LIGHT,LIGHT,VERY_LIGHT;
}
