package intellect25.model.characteristic;

import intellect25.model.Calculation;

/**
 * This class enumerates types of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public enum Gemstone implements TypeStone {
	DIAMOND(3.52f,1d),SAPPHIRE(3.99f,0.7d),RUBY(3.99f,0.5d),ALEXANDRITE(3.71f,0.3d);

	private float density; //density of stone
	private double basePrice; // base price

	/**
	 * Constructor
	 *
	 * @param density density of stone
	 * @param basePrice base price
	 */
	Gemstone(float density, double basePrice){
		this.density = density;
		this.basePrice = basePrice;
	}

	/**
	 * Get density of stone
	 *
	 * @return density
	 */
	private float getDensity(){
		return density;
	}

	/**
	 * Get base price
	 *
	 * @return base price
	 */
	public double getBasePrice(){
		return basePrice;
	}

	/**
	 * Get weight of stone
	 *
	 * @param form Form of stone
	 * @param diametrOrLenght diametr or lenght of stone
	 * @param widht widht of stone
	 * @param height height of stone
	 * @return weight of stone
	 */
	public double getWeight(Form form,float diametrOrLenght,float widht,float height){
		if(Form.ROUND == form) widht = diametrOrLenght;
		double weight = getWeightForSet(form, diametrOrLenght, widht, height);
		return weight;
	}

	/**
	 * Helper for getWeight
	 *
	 * @param form Form of stone
	 * @param diametrOrLenght  diametr or lenght of stone
	 * @param widht widht of stone
	 * @param height height of stone
	 * @return weight of stone
	 */
	private double getWeightForSet(Form form,float diametrOrLenght,float widht,float height){
		return Calculation.round((diametrOrLenght * widht * height * getDensity() * form.getProperty()), AFTER_POINT);
	}

	/**
	 * Check this class is DIAMOND
	 *
	 * @return true or false
	 */
	public boolean isDiamond(){
		return Gemstone.DIAMOND.equals(this);
	}

}
