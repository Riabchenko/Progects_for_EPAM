package intellect25.model.characteristic;

/**
 * This class enumerates Colors of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public enum ColorOfDiamond implements Color {
	Z,Y,X,W,V,U,T,S,R,Q,P,O,N,M,L,K,J,I,H,G,F,E,D;
	
}
