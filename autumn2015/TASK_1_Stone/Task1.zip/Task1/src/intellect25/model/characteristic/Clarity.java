package intellect25.model.characteristic;

/**
 * This class enumerates Clarity of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public enum Clarity {
	I3,I2,I1,SI2,SI1,VS2,VS1,VVS2,VVS1;
}
