package intellect25.model;

import intellect25.model.characteristic.*;

import java.util.Random;

/**
 * This is  random stone
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class RandomStone {

    private static final int CATEGORY_STONE = 2;
    private static final int SIZE_GEMSTONE = 4;
    private static final int SIZE_SEMI_PRECIOUS = 2;
    private static final int SIZE_FORM = 7;
    private static final int SIZE_COLOR_DIAMOND = 23;
    private static final int SIZE_TONE = 5;
    private static final int SIZE_CLARITY = 9;
    private static final int SIZE_CUT = 5;
    private static final int SIZE_RANDOM_PROPORTIONS = 13;

    public static Stone create(){
        Random random = new Random();

        /* Create type of stone of Gemstone or SemiPrecious */
        TypeStone typeStone = null;
        int randomCategoryStone = random.nextInt(CATEGORY_STONE); // random number of categoryStone
        int randomNumberOfTypeStone = 0;                                // number of stone in enum
        if ((randomCategoryStone % 2) > 0) {                      // check numberTypeStone is even or isn't
            randomNumberOfTypeStone = random.nextInt(SIZE_GEMSTONE); // random number of gemstone

            int i = 0;
            for (Gemstone element : Gemstone.values()) { //search element in enum
                if (i == randomNumberOfTypeStone) typeStone = element;
                i++;
            }
        } else {
            randomNumberOfTypeStone = random.nextInt(SIZE_SEMI_PRECIOUS);// random number of semi precious

            int i = 0;
            for (SemiPrecious element : SemiPrecious.values()) { //search element in enum
                if (i == randomNumberOfTypeStone) typeStone = element;
                i++;
            }
        }

        /* Create form */
        Form form = null;
        int randomNumberOfForm = random.nextInt(SIZE_FORM); // random number of Form

        int i=0;
        for(Form element : Form.values()){ //search element in enum
            if(i==randomNumberOfForm) form = element;
            i++;
        }

        /* Create color */
        Color color = null;

        boolean is = false;
        if (typeStone instanceof Gemstone) {
            if (((Gemstone) typeStone).isDiamond()){ //check typeStone is diamond
                int randomNumberOfColor = random.nextInt(SIZE_COLOR_DIAMOND); // random number of ColorDiamond

                i = 0;
                for (ColorOfDiamond element : ColorOfDiamond.values()) { //search element in enum
                    if (i == randomNumberOfColor) color = element;
                    i++;
                }
                is = true;
            }
        }

        if (is == false) {
            int randomNumberOfColor = random.nextInt(SIZE_TONE); // random number of Tone

            int j = 0;
            for (Tone elementTone : Tone.values()) { //search element in enum
                if (j == randomNumberOfColor) color = elementTone;
                j++;
            }
        }

       /* Create clarity */
        Clarity clarity = null;
        int randomNumberOfClarity = random.nextInt(SIZE_CLARITY); // random number of Clarity

        i = 0;
        for(Clarity element : Clarity.values()){  //search element in enum
            if(i==randomNumberOfClarity) clarity = element;
            i++;
        }

        /* Create cut */
        Cut cut = null;
        int randomNumberOfCut = random.nextInt(SIZE_CUT);// random number of Cut

        i = 0;
        for(Cut element : Cut.values()){ //search element in enum
            if(i==randomNumberOfCut) cut = element;
            i++;
        }

        /* Create proportions of stone*/
        float
                diametrOrLenght = 0,
                height = 0,
                widht = 0;
        while(diametrOrLenght<=1) diametrOrLenght = random.nextFloat()*random.nextInt(SIZE_RANDOM_PROPORTIONS);
        while(height<=1) height = random.nextFloat()*random.nextInt(SIZE_RANDOM_PROPORTIONS);
        while(widht<=1) widht = random.nextFloat()*random.nextInt(SIZE_RANDOM_PROPORTIONS);

        return new Stone(typeStone,color,clarity,cut,form,diametrOrLenght,widht,height); // return new stone
    }
}
