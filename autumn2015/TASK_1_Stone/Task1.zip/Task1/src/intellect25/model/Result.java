package intellect25.model;

/**
 * This class for storing results
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Result {

    /** Weight of a necklace */
    private double weight;

    /** Price of a necklace */
    private double price;

    /**
     * Constructor with entered parameters
     *
     * @param weight weight of a necklace
     * @param price price of a necklace
     */
    public Result(double weight, double price) {
        this.weight = weight;
        this.price = price;
    }

    /**
     * Get weight of a necklace
     *
     * @return weight
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Get weight of a necklace as String
     *
     * @return weight of a necklace
     */
    public String getStringWeight() {
        return String.valueOf(weight);
    }

    /**
     * Set weight of a necklace
     *
     * @param weight weight of a necklace
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }

    /**
     * Get price of a necklace
     *
     * @return price of a necklace
     */
    public double getPrice() {
        return price;
    }

    /**
     * Get price of a necklace as String
     *
     * @return price as String
     */
    public String getStringPrice() {
        return String.valueOf(price);
    }

    /**
     * Set price of a necklace
     *
     * @param price price
     */
    public void setPrice(double price) {
        this.price = price;
    }
}
