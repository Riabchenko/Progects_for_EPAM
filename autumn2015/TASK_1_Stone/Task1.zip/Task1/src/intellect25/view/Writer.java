package intellect25.view;

import intellect25.model.Necklace;
import intellect25.model.Result;
import intellect25.model.Stone;

/**
 * This class for a display data
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Writer {

    /**
     * Display data
     *
     * @param text entered text
     */
    public static void out(Object text){
        System.out.println(String.valueOf(text));
    }

    /**
     * Display result
     *
     * @param necklace necklace
     */
    public static void printResult(Necklace necklace){
        printTitle();
        print(necklace);
        printTotal(necklace.resultWeightPrice());
    }

    /**
     * Display incorrect result
     *
     * @param necklace necklace
     */
    public static void printIncorrectResult(Necklace necklace){
        printTitle();
        print(necklace);
    }

    /**
     * Display the title
     */
    private static void printTitle(){
        System.out.println("======================================================================================================================");
        System.out.format("%-20s %10s %20s %15s %15s %15s %15s\n","Stone","Form","Clarity","Color","Cut","Weight"," Price");
        System.out.format("%-20s %10s %20s %15s %15s %15s %15s\n","-------","-------","-------","-------","-------","-------","-------");
    }

    /**
     * Display the data
     *
     * @param necklace necklace
     */
    private static void print(Necklace necklace){
        for (Stone stone : necklace.getNecklace())
            System.out.format("%-20s %10s %20s %15s %15s %15s %15s\n",stone.getTypeStone(),stone.getForm(),stone.getClarity(), stone.getColor(), stone.getCut(), stone.getWeight(),stone.getPrice());
    }

    /**
     * Display the total
     *
     * @param result result
     */
    private static void printTotal(Result result){
        System.out.format("%-20s %10s %20s %15s %15s %15s %15s\n","-------","-------","-------","-------","-------","-------","-------");
        System.out.format("%-20s %10s %20s %15s %15s %15s %15s\n","Total","","","","", result.getStringWeight(),result.getStringPrice());
    }
}
