package intellect25.controller;

import intellect25.model.*;
import intellect25.model.characteristic.*;
import intellect25.view.Writer;

import java.util.*;

/**
 *  This class creates necklaces,
 *  sort stones of necklace by price,
 *  select by clarity of stones
 *
 * @version 1.00
 * @author Riabchenko Aliona
 */
public class Reception {

    /** Messages */
    final static String BAD_DATA = "Incorrect a stone";
    final static String CREATE_AUTOMAT = "\n\nCreated automatically a necklace:";
    final static String SORT_MESSAGE = "\n\nSort a necklace by price:";
    final static String CHOOSE_BY_CLARITY = "\n\nChoose a necklace by clarity:";
    final static String CREATE = "\n\nCreated a necklace:";

    /**
     * Client
     *
     * @param args entered data
     */
    public static void main(String [] args){

        /* Create automatically necklace*/
        Writer.out(CREATE_AUTOMAT);// Display message
        Necklace necklace = Factory.createNecklace(10); //Create a necklace
        Writer.printResult(necklace);// Display result

        /* Sort*/
        Writer.out(SORT_MESSAGE);// Display message
        sortNecklace(necklace);// Sort a necklace
        Writer.printResult(necklace); // Display result

        /* Choose stones by clarity*/
        Writer.out(CHOOSE_BY_CLARITY);// Display message
        Clarity minClarity = Clarity.I1; // first parameter of clarity
        Clarity maxClarity = Clarity.VS1;// second parameter of clarity
        List<Stone> listStone = selectClarity(necklace, minClarity, maxClarity); // get list with result
        Necklace necklaceByClarity = Factory.createNecklace(listStone);
        Writer.printResult(necklaceByClarity);// Display result

        /* Create necklace */
        Writer.out(CREATE);// Display message
        List<Stone> list = new LinkedList<>();

        /* Create stone */
        Stone stone = new Stone(Gemstone.ALEXANDRITE, Tone.DARK, Clarity.I1, Cut.EXCELLENT, Form.BAGUETTE,10f,10f,10f);
        Stone stone1 = new Stone(Gemstone.DIAMOND,Tone.DARK,Clarity.I1,Cut.EXCELLENT, Form.BAGUETTE,10f,10f,10f);
        list.add(stone); //add stone to the list
        list.add(stone1);//add stone to the list
        Necklace handMakeNecklace = Factory.createNecklace(list); //create NecklaceImpl

        //if is incorrect color of stone at the necklace than will show message 'Incorrect a stone'
        if (!handMakeNecklace.checkPrice()){
            Writer.out(BAD_DATA);
            Writer.printIncorrectResult(handMakeNecklace);
        } else {
            Writer.printResult(handMakeNecklace);
        }


    }

    /**
     * Sort necklace by clarity
     *
     * @param necklace entered necklace
     */
    public static void sortNecklace(Necklace necklace){

        Comparator comparatorPrice = new Comparator<Stone>() {
            @Override
            public int compare(Stone o1, Stone o2) {
                return ((int)o1.getPrice())-((int)o2.getPrice());
            }
        };

        LinkedList tempNecklace = necklace.getNecklace(); // new temp necklace from real necklace
        Collections.sort(tempNecklace, comparatorPrice); //sort
        necklace.setNecklace(tempNecklace); //set sort necklace to real necklace

    }

    /**
     * Select on a specified range of clarity - the first value is minimum clarity, the second value is maximum clarity
     *
     * @param necklace entered necklace
     * @param minClarity minimum clarity
     * @param maxClarity maximum clarity
     * @return list of result
     */
    public static List<Stone> selectClarity(Necklace necklace,Clarity minClarity,Clarity maxClarity){
		int min = minClarity.ordinal();
		int max = maxClarity.ordinal();
		List<Stone> selected = new ArrayList();// create list for result

		if(min<=max){
			for (Stone stone : necklace.getNecklace()){
				if(stone.getClarity().ordinal() >= min && stone.getClarity().ordinal() <= max)
					selected.add(stone);
			}
		}

        Comparator comparatorClarity = new Comparator<Stone>() {
            @Override
            public int compare(Stone o1, Stone o2) {
                return (int)(o1.getClarity().ordinal() - o2.getClarity().ordinal());
            }
        };

        Collections.sort(selected,comparatorClarity); //sort
		return selected;
	}
}
